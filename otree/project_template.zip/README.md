django-otree-project-template
=============================

Template for oTree projects
