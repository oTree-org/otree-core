from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect

import {{ app_name }}.models
import ptree.views.abstract
import ptree.views.abstract
import ptree.views.concrete
import {{ app_name }}.forms

from django.conf import settings

class View(object):
    """Keep this as is"""
    Treatment = {{ app_name }}.models.Treatment
    Match = {{ app_name }}.models.Match
    Player = {{ app_name }}.models.Player
    Experiment = {{ app_name }}.models.Experiment
    
class Start(ptree.views.abstract.Start, View):
    """Keep this as is"""

# change the name as necessary
class MyView(View, ptree.views.abstract.PageWithModelForm):

    # substitute the 
    form_class = {{ app_name }}.forms.MyModelForm
    template_name = '{{ app_name }}/MyView.html'

    def is_displayed(self):
        """whether this view is displayed to the current. By default, returns True.
        But you can make it depend on properties of self.player, self.match, self.treatment, etc.
        """

    def get_template_variables(self):
        """
        Get any variables that will be passed to the HTML template.
        Add them to the dictionary as key-value pairs.
        
        Here's an example::
        
                return {'CHARITY': CHARITY,
                    'is_hypothetical': self.treatment.probability_of_honoring_split_as_fraction() == 0,
                    'max_offer_amount': self.treatment.max_offer_amount,
                    'player_gets_all_money_if_no_honor_split': self.treatment.player_gets_all_money_if_no_honor_split}

        
        (You don't need to include the form; that will be handled automatically)
        """
       
        return {}

    def after_form_validates(self, form):
        """
        After the user submits the form,
        pTree makes sure that it has all the required values
        (and re-displays to the user with errors otherwise).
        
        Here you can put anything additional that should happen after the form validates.
        
        If you used Form rather than ModelForm, you will need to save the form fields to the database yourself here.
        
        You can access form fields like this::
        
            password = form.cleaned_data['password']
        """
        
        
# add more Views as you wish...        
