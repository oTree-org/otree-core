# Don't change anything in this file.
import {{ app_name }}.models

class ViewInThisApp(object):
    """Keep this as is"""
    TreatmentClass = {{ app_name }}.models.Treatment
    MatchClass = {{ app_name }}.models.Match
    ParticipantClass = {{ app_name }}.models.Participant
    ExperimentClass = {{ app_name }}.models.Experiment

    def autocomplete_dummy_method(self):
        """
        never actually gets called :)
        only exists to declare frequently used instance vars,
        so that the IDE's IntelliSense/code completion finds these attributes
        to make writing code faster.
        """

        self.experiment = {{ app_name }}.models.Experiment()
        self.treatment = {{ app_name }}.models.Treatment()
        self.match = {{ app_name }}.models.Match()
        self.participant = {{ app_name }}.models.Participant()

class PickTreatment(ptree.views.abstract.PickTreatment, ViewInThisApp):
    pass
