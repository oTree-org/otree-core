import ptree.views.abstract
import ptree.views.concrete
import {{ app_name }}.forms
from {{ app_name }}.utilities import ViewInThisApp, PickTreatment

from django.conf import settings

class Start(ptree.views.abstract.Start, ViewInThisApp):
    """Only change this if you don't want to use the standard start page
    in ptree/Start.html
    """

# change the name as necessary
class MyView(ViewInThisApp, ptree.views.abstract.PageWithModelForm):

    # substitute the 
    form_class = {{ app_name }}.forms.MyForm
    template_name = '{{ app_name }}/MyView.html'

    def is_displayed(self):
        return True

    def get_variables_for_template(self):
        return {}

    def after_form_validates(self, form):
        pass
        
# add more Views as you wish...        
